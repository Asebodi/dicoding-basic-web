## Tugas Akhir Dasar Pemograman Web Dicoding

Semua foto ilustrasi diambil dari Freepik dan kemudian di-edit sedikit supaya sesuai dengan penggunaan di sini. Desain yang terlampir di folder "Design" dibuat di Adobe XD setelah terinspirasi dari salah satu postingan UI/UX yang saya follow di Instagram.

Seluruh CSS di web ini ditulis menggunakan format Sass. Saya harap ini tidak menyalahi aturan karena Sass bukan merupakan tool untuk menyusun layout seperti Bootstrap dsb dan di halaman tugas tidak ada keterangan mengenai Sass. Saya hanya menggunakan fitur nesting dan variabel dari Sass ini, sisanya murni CSS bawaan. Jadi saya harap ini tidak menyalahi aturan.

Seluruh HTML, CSS, dan Javascript yang ada disini merupakan hasil penulisan saya sendiri. Banyak penamaan class yang tidak konsisten karena ditulis dalam jangka beberapa hari dikarenakan saya yang sedang sibuk dengan kegiatan kampus. Mohon dimaklumi 😐.

Bagian scrolling "clients" di sini terinspirasi dari website Framer yang masih aktif beberapa waktu yang lalu sebelum diganti ke versi yang lebih bagus wkwk. Pendekatannya sama, tapi saya membangun ulang keseluruhannya dari kosong.

Dan iya, saya tahu beberapa "buzzword" di deskripsi perusahaan tidak sesuai dengan tema perusahaan palsu ini. Itu hanyalah setengah sarkas dari saya yang terlalu sering melihat kata-kata tersebut hingga rasanya tidak ada artinya lagi 😅.
